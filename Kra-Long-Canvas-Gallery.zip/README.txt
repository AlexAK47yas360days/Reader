KRA LONG CANVAS — folder gallery
================================

HOW TO USE
1. Drop your image files (jpg, png, gif, webp, avif, bmp) into the
   "images" folder.
2. Open the gallery. Every image in the "images" folder is shown
   automatically — no "Add" button, nothing to configure.

IMPORTANT — run a local server, don't just double-click index.html
--------------------------------------------------------------------
Browsers block a plain HTML file (opened via double-click, "file://")
from reading the contents of a folder for security reasons. To let
the page see what's inside "images", serve the folder instead:

  Option A (Python, usually already installed):
    open a terminal in this folder and run:
        python3 -m http.server 8000
    then visit:
        http://localhost:8000/

  Option B (Node):
        npx serve .

  Option C: upload the whole folder to any static host (Netlify,
  GitHub Pages, etc.) — it will work the same way there.

If you truly cannot run a server, you can instead list your filenames
by hand in images/manifest.json, e.g.:
    ["photo1.jpg", "photo2.png"]

CONTROLS
- Drag / swipe left-right to browse.
- Left / Right arrow keys also move between images.
- The pill in the bottom-right shows your position (e.g. "3 / 12").

WHAT CHANGED FROM THE ORIGINAL
- The left/right arrow buttons were removed (drag and arrow keys
  still work).
- The "+ Add" upload button was removed.
- Images now come from the "images" folder automatically instead of
  being uploaded by hand.
